import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const ink = Color(0xFF0E3B38);       // أخضر زيتي داكن
  static const mist = Color(0xFFF2F6F4);      // خلفية فاتحة
  static const gold = Color(0xFFB08A2E);      // للآية الجارية فقط
  static const goldSoft = Color(0xFFF6EBCB);
}

ThemeData buildTheme() {
  final base = ColorScheme.fromSeed(
    seedColor: AppColors.ink,
    primary: AppColors.ink,
    surface: AppColors.mist,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: base,
    scaffoldBackgroundColor: AppColors.mist,
    textTheme: GoogleFonts.readexProTextTheme(),
    appBarTheme: AppBarTheme(
      backgroundColor: AppColors.mist,
      foregroundColor: AppColors.ink,
      elevation: 0,
      titleTextStyle: GoogleFonts.readexPro(
          fontSize: 20, fontWeight: FontWeight.w600, color: AppColors.ink),
    ),
  );
}

TextStyle quranStyle({double size = 26, Color? color}) =>
    GoogleFonts.amiriQuran(fontSize: size, height: 2.0, color: color ?? Colors.black87);
