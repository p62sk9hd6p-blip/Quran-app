class Surah {
  final int number;
  final String name;
  final int ayahCount;
  final String revelation;
  Surah(this.number, this.name, this.ayahCount, this.revelation);

  factory Surah.fromJson(Map<String, dynamic> j) => Surah(
        j['number'],
        j['name'],
        j['numberOfAyahs'],
        j['revelationType'] == 'Meccan' ? 'مكية' : 'مدنية',
      );
}

class Ayah {
  final int globalNumber; // الرقم في المصحف كله (يُستخدم للصوت)
  final int numberInSurah;
  final int surah;
  final int page;
  final int juz;
  final String text;
  Ayah(this.globalNumber, this.numberInSurah, this.surah, this.page, this.juz, this.text);

  factory Ayah.fromJson(Map<String, dynamic> j, int surah) => Ayah(
        j['number'],
        j['numberInSurah'],
        surah,
        j['page'],
        j['juz'],
        j['text'],
      );
}

class Reciter {
  final String id;
  final String name;
  const Reciter(this.id, this.name);
}

const reciters = <Reciter>[
  Reciter('ar.alafasy', 'مشاري العفاسي'),
  Reciter('ar.husary', 'محمود خليل الحصري'),
  Reciter('ar.minshawi', 'محمد صديق المنشاوي'),
  Reciter('ar.abdulbasitmurattal', 'عبدالباسط عبدالصمد (مرتل)'),
  Reciter('ar.hudhaify', 'علي الحذيفي'),
];
