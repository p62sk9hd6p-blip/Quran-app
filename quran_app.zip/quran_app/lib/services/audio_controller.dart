import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import '../models/quran.dart';
import 'quran_service.dart';

/// يشغّل مدى من الآيات آيةً بآية، مع تكرار الآية وتكرار المدى.
class AudioController extends ChangeNotifier {
  final _player = AudioPlayer();
  List<Ayah> _queue = [];
  int _index = 0;
  int _ayahLoop = 0;
  int _rangeLoop = 0;

  Reciter reciter = reciters.first;
  int repeatAyah = 1;
  int repeatRange = 1; // 0 = بلا نهاية
  bool playing = false;
  bool loading = false;

  Ayah? get current => _queue.isEmpty ? null : _queue[_index];
  int? get currentGlobal => current?.globalNumber;

  AudioController() {
    _player.playerStateStream.listen((s) {
      loading = s.processingState == ProcessingState.loading ||
          s.processingState == ProcessingState.buffering;
      playing = s.playing && s.processingState != ProcessingState.completed;
      if (s.processingState == ProcessingState.completed) _onAyahDone();
      notifyListeners();
    });
  }

  Future<void> playRange(List<Ayah> ayahs, {int startAt = 0}) async {
    _queue = ayahs;
    _index = startAt;
    _ayahLoop = 0;
    _rangeLoop = 0;
    await _playCurrent();
  }

  Future<void> _playCurrent() async {
    final a = current;
    if (a == null) return;
    try {
      await _player.setUrl(QuranService.audioUrl(reciter.id, a.globalNumber));
      notifyListeners();
      _player.play();
    } catch (_) {
      playing = false;
      notifyListeners();
    }
  }

  Future<void> _onAyahDone() async {
    _ayahLoop++;
    if (_ayahLoop < repeatAyah) return _playCurrent();
    _ayahLoop = 0;
    if (_index < _queue.length - 1) {
      _index++;
      return _playCurrent();
    }
    _rangeLoop++;
    if (repeatRange == 0 || _rangeLoop < repeatRange) {
      _index = 0;
      return _playCurrent();
    }
    await stop();
  }

  Future<void> toggle() async {
    if (_player.playing) {
      await _player.pause();
    } else if (current != null) {
      _player.play();
    }
  }

  Future<void> next() async {
    if (_index < _queue.length - 1) {
      _index++;
      _ayahLoop = 0;
      await _playCurrent();
    }
  }

  Future<void> previous() async {
    if (_index > 0) {
      _index--;
      _ayahLoop = 0;
      await _playCurrent();
    }
  }

  Future<void> stop() async {
    await _player.stop();
    _queue = [];
    playing = false;
    notifyListeners();
  }

  void setReciter(Reciter r) {
    reciter = r;
    notifyListeners();
    if (current != null) _playCurrent();
  }

  void setRepeatAyah(int n) { repeatAyah = n; notifyListeners(); }
  void setRepeatRange(int n) { repeatRange = n; notifyListeners(); }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}
