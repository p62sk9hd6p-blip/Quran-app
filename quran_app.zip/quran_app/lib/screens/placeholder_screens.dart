import 'package:flutter/material.dart';

class _Soon extends StatelessWidget {
  final String title;
  final String note;
  const _Soon(this.title, this.note);
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Text(note, textAlign: TextAlign.center),
          ),
        ),
      );
}

class RecitationScreen extends StatelessWidget {
  const RecitationScreen({super.key});
  @override
  Widget build(BuildContext context) =>
      const _Soon('التسميع', 'قائمة الطلاب وجلسات التسميع وتسجيل الأخطاء: المرحلة التالية.');
}

class ImaniScheduleScreen extends StatelessWidget {
  const ImaniScheduleScreen({super.key});
  @override
  Widget build(BuildContext context) =>
      const _Soon('الجدول الإيماني', 'جدولك الخاص من العبادات والمهام اليومية: المرحلة القادمة.');
}
