import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/quran.dart';
import '../services/audio_controller.dart';
import '../services/quran_service.dart';
import '../theme/app_theme.dart';

class SurahScreen extends StatefulWidget {
  final Surah surah;
  const SurahScreen({super.key, required this.surah});
  @override
  State<SurahScreen> createState() => _SurahScreenState();
}

class _SurahScreenState extends State<SurahScreen> {
  late Future<List<Ayah>> _future;
  List<Ayah> _ayahs = [];
  final _keys = <int, GlobalKey>{};
  int? _lastScrolled;

  @override
  void initState() {
    super.initState();
    _future = context.read<QuranService>().ayahs(widget.surah.number);
  }

  void _scrollTo(int global) {
    if (_lastScrolled == global) return;
    _lastScrolled = global;
    final ctx = _keys[global]?.currentContext;
    if (ctx != null) {
      Scrollable.ensureVisible(ctx,
          duration: const Duration(milliseconds: 300), alignment: 0.3);
    }
  }

  @override
  Widget build(BuildContext context) {
    final audio = context.watch<AudioController>();
    final cur = audio.currentGlobal;
    if (cur != null) WidgetsBinding.instance.addPostFrameCallback((_) => _scrollTo(cur));

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.surah.name),
        actions: [
          IconButton(
            tooltip: 'استمع للسورة كاملة',
            icon: const Icon(Icons.play_circle_outline),
            onPressed: () => audio.playRange(_ayahs),
          ),
        ],
      ),
      body: FutureBuilder<List<Ayah>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return const Center(child: Text('تعذّر تحميل السورة. تأكد من الاتصال بالإنترنت.'));
          }
          _ayahs = snap.data!;
          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
            itemCount: _ayahs.length,
            itemBuilder: (_, i) {
              final a = _ayahs[i];
              final isCur = a.globalNumber == cur;
              final key = _keys.putIfAbsent(a.globalNumber, () => GlobalKey());
              // البسملة تأتي ضمن نص الآية الأولى في هذا المصدر عدا الفاتحة والتوبة
              var text = a.text;
              const basmala = 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ';
              if (a.numberInSurah == 1 && widget.surah.number != 1 && text.startsWith(basmala)) {
                text = text.substring(basmala.length).trim();
              }
              return Column(
                key: key,
                children: [
                  if (a.numberInSurah == 1 && widget.surah.number != 1 && widget.surah.number != 9)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Text(basmala,
                          textAlign: TextAlign.center, style: quranStyle(size: 24)),
                    ),
                  InkWell(
                    onTap: () => audio.playRange(_ayahs, startAt: i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
                      decoration: BoxDecoration(
                        color: isCur ? AppColors.goldSoft : Colors.transparent,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text.rich(
                        TextSpan(children: [
                          TextSpan(text: '$text '),
                          TextSpan(
                              text: '﴿${_arabicDigits(a.numberInSurah)}﴾',
                              style: const TextStyle(color: AppColors.gold)),
                        ]),
                        textAlign: TextAlign.justify,
                        style: quranStyle(size: 26),
                      ),
                    ),
                  ),
                ],
              );
            },
          );
        },
      ),
      bottomSheet: audio.current == null ? null : const _PlayerBar(),
    );
  }
}

String _arabicDigits(int n) {
  const d = '٠١٢٣٤٥٦٧٨٩';
  return '$n'.split('').map((c) => d[int.parse(c)]).join();
}

class _PlayerBar extends StatelessWidget {
  const _PlayerBar();

  @override
  Widget build(BuildContext context) {
    final audio = context.watch<AudioController>();
    final a = audio.current!;
    return Material(
      color: AppColors.ink,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              IconButton(
                  color: Colors.white,
                  icon: const Icon(Icons.skip_next),
                  onPressed: audio.next),
              audio.loading
                  ? const Padding(
                      padding: EdgeInsets.all(12),
                      child: SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)))
                  : IconButton(
                      color: Colors.white,
                      iconSize: 36,
                      icon: Icon(audio.playing ? Icons.pause_circle : Icons.play_circle),
                      onPressed: audio.toggle),
              IconButton(
                  color: Colors.white,
                  icon: const Icon(Icons.skip_previous),
                  onPressed: audio.previous),
              Expanded(
                child: Text('الآية ${_arabicDigits(a.numberInSurah)} • ${audio.reciter.name}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white)),
              ),
              IconButton(
                  color: Colors.white,
                  icon: const Icon(Icons.tune),
                  tooltip: 'القارئ والتكرار',
                  onPressed: () => _settings(context)),
              IconButton(
                  color: Colors.white,
                  icon: const Icon(Icons.close),
                  onPressed: audio.stop),
            ]),
          ]),
        ),
      ),
    );
  }

  void _settings(BuildContext context) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => ChangeNotifierProvider.value(
        value: context.read<AudioController>(),
        child: const _SettingsSheet(),
      ),
    );
  }
}

class _SettingsSheet extends StatelessWidget {
  const _SettingsSheet();

  @override
  Widget build(BuildContext context) {
    final audio = context.watch<AudioController>();
    return SafeArea(
      child: ListView(shrinkWrap: true, padding: const EdgeInsets.all(16), children: [
        const Text('القارئ', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final r in reciters)
            ChoiceChip(
              label: Text(r.name),
              selected: audio.reciter.id == r.id,
              onSelected: (_) => audio.setReciter(r),
            ),
        ]),
        const SizedBox(height: 20),
        const Text('تكرار كل آية', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          for (final n in [1, 2, 3, 5, 10])
            ChoiceChip(
              label: Text('$n×'),
              selected: audio.repeatAyah == n,
              onSelected: (_) => audio.setRepeatAyah(n),
            ),
        ]),
        const SizedBox(height: 20),
        const Text('تكرار المقطع كاملاً', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          for (final n in [1, 2, 3, 5, 0])
            ChoiceChip(
              label: Text(n == 0 ? 'بلا توقف' : '$n×'),
              selected: audio.repeatRange == n,
              onSelected: (_) => audio.setRepeatRange(n),
            ),
        ]),
      ]),
    );
  }
}
