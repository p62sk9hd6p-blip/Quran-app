import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/quran.dart';
import '../services/quran_service.dart';
import '../theme/app_theme.dart';
import 'surah_screen.dart';

class MushafScreen extends StatefulWidget {
  const MushafScreen({super.key});
  @override
  State<MushafScreen> createState() => _MushafScreenState();
}

class _MushafScreenState extends State<MushafScreen> {
  late Future<List<Surah>> _future;
  String _q = '';

  @override
  void initState() {
    super.initState();
    _future = context.read<QuranService>().surahs();
  }

  void _retry() => setState(() => _future = context.read<QuranService>().surahs());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المصحف')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
          child: TextField(
            onChanged: (v) => setState(() => _q = v.trim()),
            decoration: InputDecoration(
              hintText: 'ابحث عن سورة',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            ),
          ),
        ),
        Expanded(
          child: FutureBuilder<List<Surah>>(
            future: _future,
            builder: (context, snap) {
              if (snap.connectionState != ConnectionState.done) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snap.hasError) {
                return Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Text('تعذّر تحميل السور. تأكد من الاتصال بالإنترنت.'),
                    const SizedBox(height: 12),
                    FilledButton(onPressed: _retry, child: const Text('إعادة المحاولة')),
                  ]),
                );
              }
              final list = snap.data!
                  .where((s) => _q.isEmpty || s.name.contains(_q) || '${s.number}' == _q)
                  .toList();
              return ListView.separated(
                itemCount: list.length,
                separatorBuilder: (_, __) => const Divider(height: 1, indent: 72),
                itemBuilder: (_, i) {
                  final s = list[i];
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: AppColors.ink,
                      foregroundColor: Colors.white,
                      child: Text('${s.number}', style: const TextStyle(fontSize: 13)),
                    ),
                    title: Text(s.name, style: quranStyle(size: 22).copyWith(height: 1.4)),
                    subtitle: Text('${s.revelation} • ${s.ayahCount} آية'),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => SurahScreen(surah: s))),
                  );
                },
              );
            },
          ),
        ),
      ]),
    );
  }
}
