# تطبيق حفظ ومراجعة القرآن

## التشغيل
1. ثبّت Flutter: https://docs.flutter.dev/get-started/install
2. داخل مجلد المشروع شغّل:
   flutter create . --platforms=android,ios --project-name quran_app
   (ينشئ مجلدي android وios دون المساس بمجلد lib)
3. flutter pub get
4. flutter run

## ملاحظات
- iOS: لا حاجة لأذونات إضافية للتشغيل عبر الإنترنت.
- Android: أضف إذن الإنترنت في android/app/src/main/AndroidManifest.xml:
  <uses-permission android:name="android.permission.INTERNET"/>
  (يُضاف تلقائياً عادةً في نسخة debug فقط).
