import 'package:firebase_core/firebase_core.dart';

/// الصق هنا قيم مشروعك من Firebase (إعدادات المشروع ← تطبيق الويب).
/// ما دامت القيمة تبدأ بـ PASTE يعمل التطبيق بدون تسجيل دخول (وضع محلي).
const firebaseOptions = FirebaseOptions(
  apiKey: 'PASTE_API_KEY',
  authDomain: 'PASTE_AUTH_DOMAIN',
  projectId: 'PASTE_PROJECT_ID',
  storageBucket: 'PASTE_STORAGE_BUCKET',
  messagingSenderId: 'PASTE_SENDER_ID',
  appId: 'PASTE_APP_ID',
);

bool get firebaseConfigured => !firebaseOptions.apiKey.startsWith('PASTE');
