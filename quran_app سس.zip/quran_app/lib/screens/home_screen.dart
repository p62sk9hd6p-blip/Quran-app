import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/data_store.dart';
import '../services/quran_service.dart';
import '../theme/app_theme.dart';

class HomeScreen extends StatefulWidget {
  final void Function(int) onGo;
  final VoidCallback? onLogout;
  const HomeScreen({super.key, required this.onGo, this.onLogout});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    context.read<QuranService>().surahs().then((_) {
      if (mounted) setState(() {});
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    final db = context.watch<DataStore>();
    final svc = context.read<QuranService>();
    final recent = ([...db.sessions]..sort((a, b) => b.date.compareTo(a.date))).take(4).toList();
    final avg = db.sessions.isEmpty
        ? 0
        : (db.sessions.map((s) => s.score).reduce((a, b) => a + b) / db.sessions.length).round();

    return Scaffold(
      body: ListView(padding: EdgeInsets.zero, children: [
        Container(
          padding: EdgeInsets.fromLTRB(20, MediaQuery.of(context).padding.top + 24, 20, 28),
          decoration: const BoxDecoration(
            color: AppColors.ink,
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text('السلام عليكم', style: quranStyle(size: 30, color: Colors.white).copyWith(height: 1.5))),
              if (widget.onLogout != null)
                IconButton(
                  tooltip: 'تسجيل الخروج',
                  icon: const Icon(Icons.logout, color: Colors.white),
                  onPressed: widget.onLogout,
                ),
            ]),
            const SizedBox(height: 4),
            const Text('وَرَتِّلِ ٱلْقُرْءَانَ تَرْتِيلًا', style: TextStyle(color: Colors.white70, fontSize: 15)),
            const SizedBox(height: 20),
            Row(children: [
              _stat('${db.students.length}', 'طلاب'),
              _stat('${db.sessions.length}', 'جلسات'),
              _stat(db.sessions.isEmpty ? '—' : '$avg%', 'متوسط الدرجات'),
            ]),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: _action(Icons.mic, 'ابدأ تسميعاً', () => widget.onGo(1))),
              const SizedBox(width: 12),
              Expanded(child: _action(Icons.menu_book, 'افتح المصحف', () => widget.onGo(2))),
            ]),
            const SizedBox(height: 12),
            _action(Icons.checklist, 'الجدول الإيماني', () => widget.onGo(3), wide: true),
            const SizedBox(height: 24),
            const Text('آخر الجلسات', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 17)),
            const SizedBox(height: 8),
            if (recent.isEmpty)
              const Text('لا توجد جلسات بعد. أضف طالباً من قسم التسميع وابدأ أول جلسة.')
            else
              for (final s in recent)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(db.student(s.studentId)?.name ?? 'طالب محذوف'),
                  subtitle: Text('${svc.nameOf(s.surah)} ${s.fromAyah}–${s.toAyah} • ${s.mistakes.length} ملاحظة'),
                  trailing: Text('${s.score}%', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.ink)),
                ),
          ]),
        ),
      ]),
    );
  }

  Widget _stat(String v, String l) => Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(v, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w600)),
          Text(l, style: const TextStyle(color: Colors.white70, fontSize: 13)),
        ]),
      );

  Widget _action(IconData i, String t, VoidCallback f, {bool wide = false}) => Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: f,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              Icon(i, color: AppColors.ink),
              const SizedBox(width: 12),
              Text(t, style: const TextStyle(fontWeight: FontWeight.w600)),
            ]),
          ),
        ),
      );
}
