import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _register = false, _busy = false, _hide = true;
  String? _error, _info;

  String _msg(String code) {
    switch (code) {
      case 'invalid-email': return 'البريد الإلكتروني غير صحيح';
      case 'weak-password': return 'كلمة المرور ضعيفة، استخدم 6 أحرف على الأقل';
      case 'email-already-in-use': return 'هذا البريد مسجّل من قبل، سجّل الدخول بدلاً من ذلك';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential': return 'البريد أو كلمة المرور غير صحيحة';
      case 'too-many-requests': return 'محاولات كثيرة، حاول بعد قليل';
      case 'network-request-failed': return 'تحقق من اتصال الإنترنت';
      default: return 'حدث خطأ ($code)';
    }
  }

  Future<void> _submit() async {
    setState(() { _busy = true; _error = null; _info = null; });
    try {
      final auth = FirebaseAuth.instance;
      final e = _email.text.trim(), p = _pass.text;
      if (_register) {
        await auth.createUserWithEmailAndPassword(email: e, password: p);
      } else {
        await auth.signInWithEmailAndPassword(email: e, password: p);
      }
    } on FirebaseAuthException catch (ex) {
      setState(() => _error = _msg(ex.code));
    } catch (_) {
      setState(() => _error = 'حدث خطأ غير متوقع');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _reset() async {
    if (_email.text.trim().isEmpty) {
      return setState(() { _error = 'اكتب بريدك أولاً'; _info = null; });
    }
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: _email.text.trim());
      setState(() { _info = 'أرسلنا رابط إعادة التعيين إلى بريدك'; _error = null; });
    } on FirebaseAuthException catch (ex) {
      setState(() => _error = _msg(ex.code));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text('حفظ ومراجعة', textAlign: TextAlign.center,
                  style: quranStyle(size: 38, color: AppColors.ink).copyWith(height: 1.5)),
              const SizedBox(height: 4),
              Text(_register ? 'أنشئ حسابك كمشرف' : 'سجّل الدخول لمتابعة طلابك',
                  textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
              const SizedBox(height: 28),
              TextField(
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(labelText: 'البريد الإلكتروني', border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _pass,
                obscureText: _hide,
                textDirection: TextDirection.ltr,
                onSubmitted: (_) => _busy ? null : _submit(),
                decoration: InputDecoration(
                  labelText: 'كلمة المرور',
                  border: const OutlineInputBorder(),
                  filled: true,
                  fillColor: Colors.white,
                  suffixIcon: IconButton(
                    icon: Icon(_hide ? Icons.visibility_off : Icons.visibility),
                    onPressed: () => setState(() => _hide = !_hide),
                  ),
                ),
              ),
              if (_error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_error!, style: const TextStyle(color: Colors.red))),
              if (_info != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_info!, style: const TextStyle(color: AppColors.ink))),
              const SizedBox(height: 20),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: AppColors.ink, padding: const EdgeInsets.all(16)),
                onPressed: _busy ? null : _submit,
                child: _busy
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(_register ? 'إنشاء الحساب' : 'تسجيل الدخول'),
              ),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () => setState(() { _register = !_register; _error = null; _info = null; }),
                child: Text(_register ? 'لديّ حساب، تسجيل الدخول' : 'ليس لديّ حساب، إنشاء حساب جديد'),
              ),
              if (!_register) TextButton(onPressed: _reset, child: const Text('نسيت كلمة المرور؟')),
            ]),
          ),
        ),
      ),
    );
  }
}
