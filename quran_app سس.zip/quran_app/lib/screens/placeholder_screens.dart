import 'package:flutter/material.dart';

class ImaniScheduleScreen extends StatelessWidget {
  const ImaniScheduleScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('الجدول الإيماني')),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(32),
            child: Text('جدولك الخاص من العبادات والمهام اليومية: المرحلة القادمة.',
                textAlign: TextAlign.center),
          ),
        ),
      );
}
