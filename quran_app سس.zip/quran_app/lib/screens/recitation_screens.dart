import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/quran.dart';
import '../models/recitation.dart';
import '../services/data_store.dart';
import '../services/quran_service.dart';
import '../theme/app_theme.dart';

Color typeColor(String t) {
  switch (t) {
    case 'نسيان': return const Color(0xFFC62828);
    case 'تبديل كلمة': return const Color(0xFFE65100);
    case 'خطأ تشكيل': return const Color(0xFF6A1B9A);
    case 'خطأ تجويد': return const Color(0xFF1565C0);
    default: return const Color(0xFFF9A825); // تردد
  }
}

String wirdText(QuranService svc, Student s) =>
    '${svc.nameOf(s.surah)} • من ${s.fromAyah} إلى ${s.toAyah}';

void _loadNames(State st, QuranService svc) {
  svc.surahs().then((_) {
    if (st.mounted) st.setState(() {});
  }).catchError((_) {});
}

/* ───────────── قائمة الطلاب ───────────── */
class RecitationScreen extends StatefulWidget {
  const RecitationScreen({super.key});
  @override
  State<RecitationScreen> createState() => _RecitationScreenState();
}

class _RecitationScreenState extends State<RecitationScreen> {
  @override
  void initState() {
    super.initState();
    _loadNames(this, context.read<QuranService>());
  }

  @override
  Widget build(BuildContext context) {
    final db = context.watch<DataStore>();
    final svc = context.read<QuranService>();
    return Scaffold(
      appBar: AppBar(title: const Text('التسميع')),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.ink,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.person_add_alt_1),
        label: const Text('إضافة طالب'),
        onPressed: () => showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          showDragHandle: true,
          builder: (_) => const AddStudentSheet(),
        ),
      ),
      body: db.students.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text('لا يوجد طلاب بعد.\nأضف أول طالب وحدّد له وِرده لتبدأ التسميع.',
                    textAlign: TextAlign.center),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.only(bottom: 96),
              itemCount: db.students.length,
              separatorBuilder: (_, __) => const Divider(height: 1, indent: 72),
              itemBuilder: (_, i) {
                final s = db.students[i];
                final n = db.sessionsOf(s.id).length;
                return ListTile(
                  leading: CircleAvatar(
                    backgroundColor: AppColors.ink,
                    foregroundColor: Colors.white,
                    child: Text(s.name.characters.first),
                  ),
                  title: Text(s.name),
                  subtitle: Text('${wirdText(svc, s)} • $n جلسة'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => StudentScreen(studentId: s.id))),
                );
              },
            ),
    );
  }
}

/* ───────────── إضافة طالب ───────────── */
class AddStudentSheet extends StatefulWidget {
  const AddStudentSheet({super.key});
  @override
  State<AddStudentSheet> createState() => _AddStudentSheetState();
}

class _AddStudentSheetState extends State<AddStudentSheet> {
  final _name = TextEditingController();
  final _from = TextEditingController(text: '1');
  final _to = TextEditingController();
  List<Surah>? _surahs;
  Surah? _surah;
  String? _error;

  @override
  void initState() {
    super.initState();
    context.read<QuranService>().surahs().then((l) {
      if (mounted) setState(() => _surahs = l);
    }).catchError((_) {
      if (mounted) setState(() => _error = 'تعذّر تحميل السور. تأكد من الاتصال.');
    });
  }

  void _save() {
    final from = int.tryParse(_from.text) ?? 0;
    final to = int.tryParse(_to.text) ?? 0;
    if (_name.text.trim().isEmpty) return setState(() => _error = 'اكتب اسم الطالب');
    if (_surah == null) return setState(() => _error = 'اختر السورة');
    if (from < 1 || to > _surah!.ayahCount || from > to) {
      return setState(() => _error = 'حدّد آيات صحيحة (1 إلى ${_surah!.ayahCount})');
    }
    context.read<DataStore>().addStudent(Student(
        DateTime.now().microsecondsSinceEpoch.toString(),
        _name.text.trim(), _surah!.number, from, to));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('طالب جديد', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          TextField(controller: _name, decoration: const InputDecoration(labelText: 'اسم الطالب', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          if (_surahs == null && _error == null) const Center(child: CircularProgressIndicator()),
          if (_surahs != null)
            DropdownButtonFormField<int>(
              decoration: const InputDecoration(labelText: 'سورة الورد', border: OutlineInputBorder()),
              items: [for (final s in _surahs!) DropdownMenuItem(value: s.number, child: Text('${s.number}. ${s.name}'))],
              onChanged: (v) => setState(() {
                _surah = _surahs![v! - 1];
                _from.text = '1';
                _to.text = '${_surah!.ayahCount}';
              }),
            ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: TextField(controller: _from, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'من آية', border: OutlineInputBorder()))),
            const SizedBox(width: 12),
            Expanded(child: TextField(controller: _to, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'إلى آية', border: OutlineInputBorder()))),
          ]),
          if (_error != null)
            Padding(padding: const EdgeInsets.only(top: 8), child: Text(_error!, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 16),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: AppColors.ink), onPressed: _save, child: const Text('حفظ الطالب')),
        ]),
      ),
    );
  }
}

/* ───────────── صفحة الطالب ───────────── */
class StudentScreen extends StatefulWidget {
  final String studentId;
  const StudentScreen({super.key, required this.studentId});
  @override
  State<StudentScreen> createState() => _StudentScreenState();
}

class _StudentScreenState extends State<StudentScreen> {
  @override
  void initState() {
    super.initState();
    _loadNames(this, context.read<QuranService>());
  }

  @override
  Widget build(BuildContext context) {
    final db = context.watch<DataStore>();
    final svc = context.read<QuranService>();
    final st = db.student(widget.studentId);
    if (st == null) return const Scaffold(body: SizedBox());
    final sessions = db.sessionsOf(st.id);

    // أكثر المواضع خطأً
    final counts = <String, int>{};
    for (final s in sessions) {
      for (final m in s.mistakes) {
        final k = '${s.surah}:${m.ayah}';
        counts[k] = (counts[k] ?? 0) + 1;
      }
    }
    final top = counts.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

    return Scaffold(
      appBar: AppBar(title: Text(st.name), actions: [
        IconButton(
          icon: const Icon(Icons.delete_outline),
          onPressed: () async {
            final ok = await showDialog<bool>(
              context: context,
              builder: (c) => AlertDialog(
                title: const Text('حذف الطالب؟'),
                content: const Text('سيُحذف الطالب وكل جلساته.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
                  TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف')),
                ],
              ),
            );
            if (ok == true && context.mounted) {
              db.deleteStudent(st.id);
              Navigator.pop(context);
            }
          },
        ),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: AppColors.ink, borderRadius: BorderRadius.circular(16)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('الورد الحالي', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 4),
            Text(wirdText(svc, st), style: quranStyle(size: 24, color: Colors.white).copyWith(height: 1.6)),
            const SizedBox(height: 12),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: AppColors.ink),
              icon: const Icon(Icons.mic),
              label: const Text('بدء جلسة تسميع'),
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => SessionScreen(student: st))),
            ),
          ]),
        ),
        const SizedBox(height: 24),
        const Text('أكثر المواضع خطأً', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
        const SizedBox(height: 8),
        if (top.isEmpty)
          const Text('ستظهر هنا بعد أول جلسة فيها أخطاء.')
        else
          for (final e in top.take(5))
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.flag_outlined, color: Color(0xFFC62828)),
              title: Text('${svc.nameOf(int.parse(e.key.split(':')[0]))} • الآية ${e.key.split(':')[1]}'),
              trailing: Text('${e.value} مرات'),
            ),
        const SizedBox(height: 24),
        const Text('الجلسات السابقة', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
        const SizedBox(height: 8),
        if (sessions.isEmpty) const Text('لا توجد جلسات بعد.'),
        for (final s in sessions)
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('${fmtDate(s.date)} • ${svc.nameOf(s.surah)} ${s.fromAyah}–${s.toAyah}'),
            subtitle: Text('${s.mistakes.length} ملاحظة'),
            trailing: Text('${s.score}%', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.ink)),
          ),
      ]),
    );
  }
}

/* ───────────── جلسة التسميع ───────────── */
class SessionScreen extends StatefulWidget {
  final Student student;
  const SessionScreen({super.key, required this.student});
  @override
  State<SessionScreen> createState() => _SessionScreenState();
}

class _SessionScreenState extends State<SessionScreen> {
  List<Ayah>? _ayahs;
  String? _error;
  final _marks = <String, String>{}; // "ayah:word" -> type

  @override
  void initState() {
    super.initState();
    final s = widget.student;
    context.read<QuranService>().ayahs(s.surah).then((all) {
      if (!mounted) return;
      setState(() => _ayahs = all.where((a) => a.numberInSurah >= s.fromAyah && a.numberInSurah <= s.toAyah).toList());
    }).catchError((_) {
      if (mounted) setState(() => _error = 'تعذّر تحميل الآيات. تأكد من الاتصال.');
    });
  }

  void _pick(int ayah, int word) {
    final key = '$ayah:$word';
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(padding: EdgeInsets.all(8), child: Text('نوع الملاحظة', style: TextStyle(fontWeight: FontWeight.w600))),
          for (final t in mistakeTypes)
            ListTile(
              leading: CircleAvatar(radius: 8, backgroundColor: typeColor(t)),
              title: Text(t),
              onTap: () {
                setState(() => _marks[key] = t);
                Navigator.pop(c);
              },
            ),
          if (_marks.containsKey(key))
            ListTile(
              leading: const Icon(Icons.undo),
              title: const Text('إزالة الملاحظة'),
              onTap: () {
                setState(() => _marks.remove(key));
                Navigator.pop(c);
              },
            ),
        ]),
      ),
    );
  }

  void _finish() {
    final s = widget.student;
    final mistakes = _marks.entries.map((e) {
      final p = e.key.split(':');
      return Mistake(int.parse(p[0]), int.parse(p[1]), e.value);
    }).toList();
    final hes = mistakes.where((m) => m.type == 'تردد').length;
    final errs = mistakes.length - hes;
    final score = (100 - errs * 3 - hes).clamp(0, 100);
    context.read<DataStore>().addSession(Session(
        DateTime.now().microsecondsSinceEpoch.toString(),
        s.id, DateTime.now(), s.surah, s.fromAyah, s.toAyah, score, mistakes));
    showDialog(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('تم حفظ الجلسة'),
        content: Text('الدرجة: $score%\nأخطاء: $errs • تردد: $hes'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(c);
              Navigator.pop(context);
            },
            child: const Text('تم'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.student;
    return Scaffold(
      appBar: AppBar(title: Text('تسميع ${s.name}'), actions: [
        Center(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text('${_marks.length} ملاحظة'))),
      ]),
      body: _error != null
          ? Center(child: Text(_error!))
          : _ayahs == null
              ? const Center(child: CircularProgressIndicator())
              : Column(children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                    child: Wrap(spacing: 12, children: [
                      for (final t in mistakeTypes)
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          CircleAvatar(radius: 5, backgroundColor: typeColor(t)),
                          const SizedBox(width: 4),
                          Text(t, style: const TextStyle(fontSize: 12)),
                        ]),
                    ]),
                  ),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Align(alignment: Alignment.centerRight, child: Text('اضغط على الكلمة لتسجيل ملاحظة', style: TextStyle(fontSize: 12, color: Colors.black54))),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(16),
                      child: Wrap(
                        textDirection: TextDirection.rtl,
                        spacing: 4,
                        runSpacing: 2,
                        children: [
                          for (final a in _ayahs!) ...[
                            for (final e in _words(a).asMap().entries)
                              GestureDetector(
                                onTap: () => _pick(a.numberInSurah, e.key),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 4),
                                  decoration: BoxDecoration(
                                    color: _marks['${a.numberInSurah}:${e.key}'] == null
                                        ? Colors.transparent
                                        : typeColor(_marks['${a.numberInSurah}:${e.key}']!).withOpacity(0.25),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(e.value, style: quranStyle(size: 26)),
                                ),
                              ),
                            Text('﴿${a.numberInSurah}﴾', style: quranStyle(size: 22, color: AppColors.gold)),
                          ],
                        ],
                      ),
                    ),
                  ),
                  SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: SizedBox(
                        width: double.infinity,
                        child: FilledButton(
                          style: FilledButton.styleFrom(backgroundColor: AppColors.ink, padding: const EdgeInsets.all(14)),
                          onPressed: _finish,
                          child: const Text('إنهاء وحفظ الجلسة'),
                        ),
                      ),
                    ),
                  ),
                ]),
    );
  }

  List<String> _words(Ayah a) {
    var t = a.text;
    // البسملة تأتي ضمن الآية الأولى في هذا المصدر عدا الفاتحة والتوبة
    if (a.numberInSurah == 1 && a.surah != 1 && a.surah != 9) {
      t = t.split(' ').skip(4).join(' ');
    }
    return t.split(' ').where((w) => w.trim().isNotEmpty).toList();
  }
}
