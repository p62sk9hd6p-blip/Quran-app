import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/quran.dart';

/// المصدر: api.alquran.cloud (نص عثماني) + cdn.islamic.network (الصوت)
class QuranService {
  static const _base = 'https://api.alquran.cloud/v1';
  final _ayahCache = <int, List<Ayah>>{};
  List<Surah>? _surahs;

  Future<List<Surah>> surahs() async {
    if (_surahs != null) return _surahs!;
    final r = await http.get(Uri.parse('$_base/surah'));
    if (r.statusCode != 200) throw Exception('تعذّر تحميل السور');
    final data = jsonDecode(r.body)['data'] as List;
    return _surahs = data.map((e) => Surah.fromJson(e)).toList();
  }

  Future<List<Ayah>> ayahs(int surah) async {
    if (_ayahCache.containsKey(surah)) return _ayahCache[surah]!;
    final r = await http.get(Uri.parse('$_base/surah/$surah/quran-uthmani'));
    if (r.statusCode != 200) throw Exception('تعذّر تحميل السورة');
    final list = jsonDecode(r.body)['data']['ayahs'] as List;
    return _ayahCache[surah] = list.map((e) => Ayah.fromJson(e, surah)).toList();
  }

  String nameOf(int n) =>
      (_surahs != null && n >= 1 && n <= _surahs!.length) ? _surahs![n - 1].name : 'سورة $n';

  static String audioUrl(String reciterId, int globalAyah) =>
      'https://cdn.islamic.network/quran/audio/128/$reciterId/$globalAyah.mp3';
}
