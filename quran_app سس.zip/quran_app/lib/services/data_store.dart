import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/recitation.dart';

/// إذا وُجد uid تُحفظ البيانات في السحابة (Firestore) لكل مشرف على حدة،
/// وإلا تُحفظ محلياً على الجهاز.
class DataStore extends ChangeNotifier {
  final String? uid;
  List<Student> students = [];
  List<Session> sessions = [];
  bool _loaded = false;

  DataStore({this.uid}) {
    _load();
  }

  DocumentReference<Map<String, dynamic>> get _doc =>
      FirebaseFirestore.instance.collection('users').doc(uid);

  Future<void> _load() async {
    try {
      String sRaw, hRaw;
      if (uid != null) {
        final d = (await _doc.get()).data() ?? {};
        sRaw = d['students'] ?? '[]';
        hRaw = d['sessions'] ?? '[]';
      } else {
        final p = await SharedPreferences.getInstance();
        sRaw = p.getString('students') ?? '[]';
        hRaw = p.getString('sessions') ?? '[]';
      }
      students = (jsonDecode(sRaw) as List)
          .map((e) => Student.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      sessions = (jsonDecode(hRaw) as List)
          .map((e) => Session.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      _loaded = true;
    } catch (_) {}
    notifyListeners();
  }

  Future<void> _save() async {
    if (!_loaded) return;
    final s = jsonEncode(students.map((e) => e.toJson()).toList());
    final h = jsonEncode(sessions.map((e) => e.toJson()).toList());
    try {
      if (uid != null) {
        await _doc.set({'students': s, 'sessions': h});
      } else {
        final p = await SharedPreferences.getInstance();
        await p.setString('students', s);
        await p.setString('sessions', h);
      }
    } catch (_) {}
  }

  void addStudent(Student s) {
    students.add(s);
    _save();
    notifyListeners();
  }

  void deleteStudent(String id) {
    students.removeWhere((s) => s.id == id);
    sessions.removeWhere((s) => s.studentId == id);
    _save();
    notifyListeners();
  }

  void addSession(Session s) {
    sessions.add(s);
    _save();
    notifyListeners();
  }

  Student? student(String id) {
    for (final s in students) {
      if (s.id == id) return s;
    }
    return null;
  }

  List<Session> sessionsOf(String studentId) =>
      sessions.where((s) => s.studentId == studentId).toList()
        ..sort((a, b) => b.date.compareTo(a.date));
}
