import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'firebase_config.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'screens/mushaf_screen.dart';
import 'screens/placeholder_screens.dart';
import 'screens/recitation_screens.dart';
import 'services/audio_controller.dart';
import 'services/data_store.dart';
import 'services/quran_service.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (firebaseConfigured) {
    await Firebase.initializeApp(options: firebaseOptions);
  }
  runApp(const QuranApp());
}

class QuranApp extends StatelessWidget {
  const QuranApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider(create: (_) => QuranService()),
        ChangeNotifierProvider(create: (_) => AudioController()),
      ],
      child: MaterialApp(
        title: 'حفظ ومراجعة',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: const AuthGate(),
      ),
    );
  }
}

/// بدون إعداد Firebase: وضع محلي. معه: تسجيل دخول وبيانات سحابية لكل مشرف.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    if (!firebaseConfigured) {
      return ChangeNotifierProvider(create: (_) => DataStore(), child: const HomeShell());
    }
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final u = snap.data;
        if (u == null) return const AuthScreen();
        return ChangeNotifierProvider(
          key: ValueKey(u.uid),
          create: (_) => DataStore(uid: u.uid),
          child: HomeShell(onLogout: () {
            context.read<AudioController>().stop();
            FirebaseAuth.instance.signOut();
          }),
        );
      },
    );
  }
}

class HomeShell extends StatefulWidget {
  final VoidCallback? onLogout;
  const HomeShell({super.key, this.onLogout});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _i, children: [
        HomeScreen(onGo: (v) => setState(() => _i = v), onLogout: widget.onLogout),
        const RecitationScreen(),
        const MushafScreen(),
        const ImaniScheduleScreen(),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.mic_none), selectedIcon: Icon(Icons.mic), label: 'التسميع'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'المصحف'),
          NavigationDestination(icon: Icon(Icons.checklist_outlined), selectedIcon: Icon(Icons.checklist), label: 'الجدول الإيماني'),
        ],
      ),
    );
  }
}
