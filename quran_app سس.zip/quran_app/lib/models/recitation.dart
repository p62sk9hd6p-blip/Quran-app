const mistakeTypes = ['نسيان', 'تبديل كلمة', 'خطأ تشكيل', 'خطأ تجويد', 'تردد'];

class Student {
  final String id;
  final String name;
  final int surah, fromAyah, toAyah;
  Student(this.id, this.name, this.surah, this.fromAyah, this.toAyah);

  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'surah': surah, 'from': fromAyah, 'to': toAyah};
  factory Student.fromJson(Map<String, dynamic> j) =>
      Student(j['id'], j['name'], j['surah'], j['from'], j['to']);
}

class Mistake {
  final int ayah, word;
  final String type;
  Mistake(this.ayah, this.word, this.type);
  Map<String, dynamic> toJson() => {'a': ayah, 'w': word, 't': type};
  factory Mistake.fromJson(Map<String, dynamic> j) => Mistake(j['a'], j['w'], j['t']);
}

class Session {
  final String id, studentId;
  final DateTime date;
  final int surah, fromAyah, toAyah, score;
  final List<Mistake> mistakes;
  Session(this.id, this.studentId, this.date, this.surah, this.fromAyah, this.toAyah,
      this.score, this.mistakes);

  Map<String, dynamic> toJson() => {
        'id': id, 'sid': studentId, 'date': date.toIso8601String(),
        'surah': surah, 'from': fromAyah, 'to': toAyah, 'score': score,
        'm': mistakes.map((e) => e.toJson()).toList(),
      };
  factory Session.fromJson(Map<String, dynamic> j) => Session(
        j['id'], j['sid'], DateTime.parse(j['date']), j['surah'], j['from'], j['to'],
        j['score'],
        (j['m'] as List).map((e) => Mistake.fromJson(Map<String, dynamic>.from(e))).toList(),
      );
}

String fmtDate(DateTime d) => '${d.day}/${d.month}/${d.year}';
